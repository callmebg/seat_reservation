// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
const db = cloud.database()

// 云函数入口函数
exports.main = async(event, context) => {
  //return event

  return await db.collection('desk').where({
    _openid: event.desk_id
  }).update({
    data: {
      // 解除占座
      isOccupied: false,
    }
  })
}