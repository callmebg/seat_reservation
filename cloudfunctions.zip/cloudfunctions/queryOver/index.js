// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
const db = cloud.database()
const _ = db.command
// 云函数入口函数
exports.main = async (event, context) => {
  return await db.collection('desk').where({
    isOccupied: true
  }).get({
    success(res) {
      console.log(res.data)
    },
    fail(res) {
      console.log("失败")
      console.log(res)
    }
  })

}